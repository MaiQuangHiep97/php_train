<?php
session_start();
require_once "bootstrap.php";
$a = new App();
// echo $a;
