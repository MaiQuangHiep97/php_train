<?php
$config['database'] = [
    'host' =>'localhost',
    'user' =>'root',
    'pass' => 'mysql',
    'db' =>'product_demo'
];
