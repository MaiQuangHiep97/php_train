<?php
// $routes['default_controller'] = 'homecontroller';
// $routes['admin/login'] = 'admin/authcontroller';
// $routes['admin/dash-board'] = 'admin/dashboardcontroller';
//$routes['admin/post/login'] = 'admin/authcontroller/login';
