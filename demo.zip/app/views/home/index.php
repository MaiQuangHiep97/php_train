<h1>Đây là view</h1>
<?php
echo $ab;
